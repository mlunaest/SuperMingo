Hello, thank you for playing my game, Supermingo!

To run the game, unzip contents and save them all in the same folder. 
Then, click on the .exe file to run the game. 


A couple notes:

-There is only one (short) level in the demo. The demo will end and automatically 
return to the title screen once the level is completed.
-While the demo is running, there is no way to pause or quit the game outside of 
the title screen.
-Domingo the Flamingo can take 3 hits before he dies and has to restart the level.
Falling off the stage counts as a hit.

***-seagulls can be killed by jumping on them!***

Good luck!